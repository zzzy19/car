#include "A_Star.h"
// Task handle


// Task function prototype

// ??????
typedef struct Node {
    int x, y;       // ????
    double g;       // ?????????????
    double h;       // ???????????
    double f;       // ??? f = g + h
    struct Node* parent; // ?????
    bool in_path;   // ????????????
} Node;

// ????????
typedef struct PriorityQueue {
    Node* nodes[MAX_QUEUE_SIZE];   // ????????
    int size;       // ??????
} PriorityQueue;

// ??????
static Node static_nodes[ROWS][COLS];             // ??????
static Node* static_path[MAX_PATH_LENGTH];        // ??????
static PriorityQueue static_pq;                   // ??????

// ???????
void init_priority_queue(PriorityQueue* pq) {
    pq->size = 0;
}

// ????
void enqueue(PriorityQueue* pq, Node* node) {
    if (pq->size >= MAX_QUEUE_SIZE) {
        return; // ????
    }

    pq->nodes[pq->size] = node;
    int current = pq->size;
    pq->size++;

    // ????
    while (current > 0) {
        int parent = (current - 1) / 2;
        if (pq->nodes[current]->f < pq->nodes[parent]->f) {
            Node* temp = pq->nodes[current];
            pq->nodes[current] = pq->nodes[parent];
            pq->nodes[parent] = temp;
            current = parent;
        }
        else {
            break;
        }
    }
}

// ????(??f??????)
Node* dequeue(PriorityQueue* pq) {
    if (pq->size == 0) {
        return NULL;
    }

    Node* min_node = pq->nodes[0];
    pq->nodes[0] = pq->nodes[pq->size - 1];
    pq->size--;

    // ????
    int current = 0;
    while (1) {
        int left = 2 * current + 1;
        int right = 2 * current + 2;
        int smallest = current;

        if (left < pq->size && pq->nodes[left]->f < pq->nodes[smallest]->f) {
            smallest = left;
        }

        if (right < pq->size && pq->nodes[right]->f < pq->nodes[smallest]->f) {
            smallest = right;
        }

        if (smallest != current) {
            Node* temp = pq->nodes[current];
            pq->nodes[current] = pq->nodes[smallest];
            pq->nodes[smallest] = temp;
            current = smallest;
        }
        else {
            break;
        }
    }

    return min_node;
}

// ????????
bool is_empty(PriorityQueue* pq) {
    return pq->size == 0;
}

// ?????????
double manhattan_distance(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) + abs(y1 - y2);
}

// A*????(??????)
Node** a_star(int grid[ROWS][COLS], int start[2], int end[2], int* path_length) {
    // ???????
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            static_nodes[i][j].x = i;
            static_nodes[i][j].y = j;
            static_nodes[i][j].g = DBL_MAX;
            static_nodes[i][j].h = DBL_MAX;
            static_nodes[i][j].f = DBL_MAX;
            static_nodes[i][j].parent = NULL;
            static_nodes[i][j].in_path = false;
        }
    }

    // ?????
    Node* start_node = &static_nodes[start[0]][start[1]];
    start_node->g = 0;
    start_node->h = manhattan_distance(start[0], start[1], end[0], end[1]);
    start_node->f = start_node->g + start_node->h;

    // ???????
    init_priority_queue(&static_pq);
    enqueue(&static_pq, start_node);

    // ????(4???:???????)
    int directions[4][2] = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };

    while (!is_empty(&static_pq)) {
        Node* current = dequeue(&static_pq);

        // ????
        if (current->x == end[0] && current->y == end[1]) {
            // ????
            Node* path[MAX_PATH_LENGTH];
            int length = 0;

            // ?????????????
            Node* temp = current;
            while (temp != NULL) {
                temp->in_path = true;  // ????????
                path[length] = temp;
                length++;
                temp = temp->parent;
            }

            // ?????????
            for (int i = 0; i < length; i++) {
                static_path[i] = path[length - 1 - i];
            }

            *path_length = length;
            return static_path;
        }

        // ??????
        for (int k = 0; k < 4; k++) {
            int nx = current->x + directions[k][0];
            int ny = current->y + directions[k][1];

            // ????????
            if (nx >= 0 && nx < ROWS && ny >= 0 && ny < COLS && grid[nx][ny] == 0) {
                Node* neighbor = &static_nodes[nx][ny];
                double tentative_g = current->g + 1; // ????????1

                // ??????
                if (tentative_g < neighbor->g) {
                    neighbor->parent = current;
                    neighbor->g = tentative_g;
                    neighbor->h = manhattan_distance(neighbor->x, neighbor->y, end[0], end[1]);
                    neighbor->f = neighbor->g + neighbor->h;

                    // ????????
                    enqueue(&static_pq, neighbor);
                }
            }
        }
    }

    // ?????
    *path_length = 0;
    return NULL;
}

// ??????
void A_star (void *pvParameters) {
    struct Car {
        int x;
        int y;
        int direc;
    };
    
    // ??????
    struct Car car = {0, 0, 0};
    
    // ????
    int grid[ROWS][COLS] = {
        {0, 0, 0, 1, 1, 0, 0, 1, 0, 0},
        {1, 0, 0, 1, 1, 0, 1, 0, 0, 0},
        {0, 1, 0, 1, 1, 0, 0, 0, 1, 0},
        {0, 0, 0, 1, 1, 0, 1, 0, 0, 0},
        {1, 0, 1, 1, 1, 0, 1, 0, 1, 0},
        {0, 0, 0, 1, 1, 1, 0, 0, 1, 0},
        {0, 1, 0, 1, 1, 0, 0, 0, 1, 0},
        {0, 0, 1, 1, 1, 1, 1, 0, 0, 0},
        {1, 0, 0, 1, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 1, 1, 0, 0, 0, 0, 0}
    };

    // ??????? [?, ?]
    int start[2] = {0, 0};
    int end[2] = {9, 0};
    
    // ????
    int path_length = 0;
    Node** path = a_star(grid, start, end, &path_length);
    
    // ??????
    int cntp = 0;
    
    // ??????
    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xDelay1 = pdMS_TO_TICKS(10000);     // 10???
    const TickType_t xDelay2 = pdMS_TO_TICKS(1000);      // 1 step
    const TickType_t xDelay2_dg = pdMS_TO_TICKS(1050);   // 90???????
    const float RC_Velocity_m = RC_Velocity / 1000;      // ????
    
    // ????
    vTaskDelayUntil(&xLastWakeTime, xDelay1);
    car.x=0;
    car.y=0;
    car.direc=0;
    // ???????
    while (cntp < path_length - 1) {
        // ??????
        car.x = path[cntp]->x;
        car.y = path[cntp]->y;
        
        // ?????????
        int dir_next = 0;
        if (car.y < path[cntp + 1]->y) dir_next = 1;      // ?
        else if (car.y > path[cntp + 1]->y) dir_next = 3; // ?
        else if (car.x < path[cntp + 1]->x) dir_next = 0; // ?
        else if (car.x > path[cntp + 1]->x) dir_next = 2; // ?

        // ??????
        int dir_diff = dir_next - car.direc;
        if (dir_diff == -3) dir_diff = 1;      // ??????
        else if (dir_diff == 3) dir_diff = -1; // ??????

        // ????
        if (dir_diff != 0) {
						vTaskDelayUntil(&xLastWakeTime, 0.5*xDelay2_dg);//wait
					
            taskENTER_CRITICAL();
            Move_Z = dir_diff * PI / 2;        // ?????
            taskEXIT_CRITICAL();
            
            vTaskDelayUntil(&xLastWakeTime, xDelay2_dg); // ????
            
            taskENTER_CRITICAL();
            Move_Z = 0;                       // ????
            taskEXIT_CRITICAL();
            
					  vTaskDelayUntil(&xLastWakeTime, 0.5*xDelay2_dg);//wait
            car.direc = dir_next;              // ????
        }
        // ????
        taskENTER_CRITICAL();
        Move_X = RC_Velocity_m;                // ??????
        taskEXIT_CRITICAL();
        
        vTaskDelayUntil(&xLastWakeTime, xDelay2); // ????
        
        taskENTER_CRITICAL();
        Move_X = 0;                           // ????
        taskEXIT_CRITICAL();
        

        cntp++; // ?????????
    }

    // ????
    taskENTER_CRITICAL();
    Move_X = 0;
    Move_Z = 0;
    taskEXIT_CRITICAL();
    
    vTaskDelete(NULL); // ????
}
