#include "sys.h"
#include "system.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#define MAX_QUEUE_SIZE     (ROWS * COLS)  // ????????
#define MAX_PATH_LENGTH    (ROWS * COLS)  // ??????

// ??????
#define ROWS 10
#define COLS 10

void A_star (void *pvParameters);
