/***********************************************
??:????(??)????
??:WHEELTEC
??:wheeltec.net
????:shop114407458.taobao.com 
???: https://minibalance.aliexpress.com/store/4455017
??:V5.0
????:2022-05-05

Brand: WHEELTEC
Website: wheeltec.net
Taobao shop: shop114407458.taobao.com 
Aliexpress: https://minibalance.aliexpress.com/store/4455017
Version: V5.0
Update:2022-05-05

All rights reserved
***********************************************/
#include "system.h"


// Task priority and stack size definitions
#define START_TASK_PRIO    1
#define START_STK_SIZE     256  

void start_task(void *pvParameters);
TaskHandle_t StartTask_Handler;
// Main function
int main(void) { 
    systemInit(); // 硬件初始化
    
    // 创建启动任务
    xTaskCreate((TaskFunction_t)start_task,     // 任务函数
                (const char*    )"start_task",  // 任务名称
                (uint16_t       )START_STK_SIZE,// 任务栈大小
                (void*          )NULL,          // 传递给任务的参数
                (UBaseType_t    )START_TASK_PRIO,// 任务优先级
                (TaskHandle_t*  )&StartTask_Handler); // 任务句柄
                
    vTaskStartScheduler(); // 启动任务调度器
}

// 启动任务
void start_task(void *pvParameters) {    
    taskENTER_CRITICAL();
    
    // 创建系统任务
    xTaskCreate(Balance_task,  "Balance_task",  BALANCE_STK_SIZE,  NULL, BALANCE_TASK_PRIO,  NULL);
    
    // 根据硬件版本创建IMU任务
    if (SysVal.HardWare_Ver == V1_0) {
        xTaskCreate(MPU6050_task, "IMU_task", IMU_STK_SIZE, NULL, IMU_TASK_PRIO, NULL);
    } else if (SysVal.HardWare_Ver == V1_1) {
        xTaskCreate(ICM20948_task, "IMU_task", IMU_STK_SIZE, NULL, IMU_TASK_PRIO, NULL);
    }
    
    xTaskCreate(show_task, "show_task", SHOW_STK_SIZE, NULL, SHOW_TASK_PRIO, NULL);
    xTaskCreate(led_task, "led_task", LED_STK_SIZE, NULL, LED_TASK_PRIO, NULL);
    xTaskCreate(data_task, "DATA_task", DATA_STK_SIZE, NULL, DATA_TASK_PRIO, NULL);
    xTaskCreate(A_star, "A_star", 512, NULL, 2, NULL);  // 创建A*路径规划任务
    
    vTaskDelete(StartTask_Handler); // 删除启动任务
    taskEXIT_CRITICAL();            // 退出临界区
}
