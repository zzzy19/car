#ifndef _PUBLIC_STDMACROS_H_
#define _PUBLIC_STDMACROS_H_

#define BIT_8b(n)       ((unsigned char)(1 << n))
#define BIT_16b(n)      ((unsigned int) (1 << n))

#endif

